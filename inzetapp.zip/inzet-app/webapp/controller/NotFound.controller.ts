import BaseController from "./BaseController";

/**
 * @namespace inzetapp.controller
 */
export default class NotFoundController extends BaseController {
	public onClose(): void {
		this.navToMaster();
	}
}
