import BaseController from "./BaseController";
import JSONModel from "sap/ui/model/json/JSONModel";
import MessageToast from "sap/m/MessageToast";
import Fragment from "sap/ui/core/Fragment";
import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import { Route$PatternMatchedEvent } from "sap/ui/core/routing/Route";
import SelectDialog, { SelectDialog$ConfirmEvent, SelectDialog$SearchEvent } from "sap/m/SelectDialog";
import Dialog from "sap/m/Dialog";
import ListBinding from "sap/ui/model/ListBinding";
import { Inzet, InzetStatus, Medewerker, Werkrooster } from "../model/types";
import formatter from "../model/formatter";

interface DetailData {
	isNew: boolean;
	editable: boolean;
	canEdit: boolean;
	busy: boolean;
	pageTitle: string;
	showLockedMessage: boolean;
	lockedMessage: string;
	medewerker: Medewerker | null;
	maatschappijID: string;
	maatschappijNaam: string;
	inzet: Omit<Inzet, "inzetID" | "personID" | "maatschappijID">;
}

const EDITABLE_STATUSES: InzetStatus[] = ["Gepland", "Actief"];

function emptyInzet(): DetailData["inzet"] {
	return {
		startdatum: "",
		einddatum: "",
		functieOfVacature: "",
		werkrooster: "Voltijds" as Werkrooster,
		contractdatum: "",
		kostEuro: 0,
		status: "Gepland"
	};
}

/**
 * @namespace inzetapp.controller
 */
export default class InzetDetailController extends BaseController {
	public formatter = formatter;

	private originalSnapshot: DetailData | null = null;
	private selectMedewerkerDialog: SelectDialog | null = null;
	private selectMaatschappijDialog: SelectDialog | null = null;
	private maatschappijInfoDialog: Dialog | null = null;
	private currentInzetID = "";

	public onInit(): void {
		this.setModel(new JSONModel(this.buildEmptyState()), "detail");

		this.getRouter().getRoute("inzetDetail")!.attachPatternMatched(this.onInzetMatched, this);
		this.getRouter().getRoute("inzetCreate")!.attachPatternMatched(this.onInzetCreateMatched, this);
	}

	private buildEmptyState(): DetailData {
		return {
			isNew: false,
			editable: false,
			canEdit: false,
			busy: false,
			pageTitle: "",
			showLockedMessage: false,
			lockedMessage: "",
			medewerker: null,
			maatschappijID: "",
			maatschappijNaam: "",
			inzet: emptyInzet()
		};
	}

	private onInzetMatched(event: Route$PatternMatchedEvent): void {
		const args = event.getParameter("arguments") as { inzetID: string };
		const service = this.getMockDataService();
		const inzet = service.findInzet(args.inzetID);
		if (!inzet) {
			this.getRouter().getTargets()?.display("notFound");
			return;
		}
		const medewerker = service.findMedewerker(inzet.personID) || null;
		const maatschappij = service.findMaatschappij(inzet.maatschappijID);
		const canEdit = EDITABLE_STATUSES.indexOf(inzet.status) !== -1;

		const { maatschappijID, ...rest } = inzet;

		const data: DetailData = {
			isNew: false,
			editable: false,
			canEdit,
			busy: false,
			pageTitle: medewerker ? `${medewerker.voornaam} ${medewerker.achternaam}` : this.getText("inzetDetailTitle"),
			showLockedMessage: !canEdit,
			lockedMessage: canEdit ? "" : this.getText("nietMeerWijzigbaar", [inzet.status]),
			medewerker,
			maatschappijID,
			maatschappijNaam: maatschappij ? maatschappij.naam : "",
			inzet: rest
		};

		(this.getModel("detail") as JSONModel).setData(data);
		this.originalSnapshot = null;
		this.currentInzetID = inzet.inzetID;
	}

	private onInzetCreateMatched(): void {
		const data = this.buildEmptyState();
		data.isNew = true;
		data.editable = true;
		data.canEdit = true;
		data.pageTitle = this.getText("nieuweInzetTitle");
		(this.getModel("detail") as JSONModel).setData(data);
		this.originalSnapshot = null;
		this.currentInzetID = "";
	}

	public onEdit(): void {
		const model = this.getModel("detail") as JSONModel;
		this.originalSnapshot = JSON.parse(JSON.stringify(model.getData())) as DetailData;
		model.setProperty("/editable", true);
	}

	public onCancel(): void {
		const model = this.getModel("detail") as JSONModel;
		const data = model.getData() as DetailData;
		if (data.isNew) {
			this.navToMaster();
			return;
		}
		if (this.originalSnapshot) {
			model.setData(this.originalSnapshot);
		}
		model.setProperty("/editable", false);
	}

	public onSave(): void {
		const model = this.getModel("detail") as JSONModel;
		const data = model.getData() as DetailData;

		if (!data.medewerker) {
			MessageToast.show(this.getText("foutGeenMedewerker"));
			return;
		}
		if (!data.maatschappijID) {
			MessageToast.show(this.getText("foutGeenMaatschappij"));
			return;
		}
		if (!data.inzet.startdatum || !data.inzet.functieOfVacature) {
			MessageToast.show(this.getText("foutVerplichteVelden"));
			return;
		}

		model.setProperty("/busy", true);
		const service = this.getMockDataService();

		if (data.isNew) {
			const created = service.addInzet({
				personID: data.medewerker.personID,
				maatschappijID: data.maatschappijID,
				...data.inzet
			});
			model.setProperty("/busy", false);
			MessageToast.show(this.getText("inzetOpgeslagen"));
			this.getRouter().navTo("inzetDetail", { inzetID: created.inzetID }, true);
		} else {
			service.updateInzet(this.currentInzetID, {
				...data.inzet,
				personID: data.medewerker.personID,
				maatschappijID: data.maatschappijID
			});
			const canEdit = EDITABLE_STATUSES.indexOf(data.inzet.status) !== -1;
			model.setProperty("/editable", false);
			model.setProperty("/canEdit", canEdit);
			model.setProperty("/showLockedMessage", !canEdit);
			model.setProperty("/lockedMessage", canEdit ? "" : this.getText("nietMeerWijzigbaar", [data.inzet.status]));
			model.setProperty("/busy", false);
			MessageToast.show(this.getText("inzetOpgeslagen"));
		}
	}

	public onClose(): void {
		this.navToMaster();
	}

	public async onSelectMedewerker(): Promise<void> {
		if (!this.selectMedewerkerDialog) {
			this.selectMedewerkerDialog = (await Fragment.load({
				id: this.getView()!.getId(),
				name: "inzetapp.view.fragment.SelectMedewerkerDialog",
				controller: this
			})) as SelectDialog;
			this.getView()!.addDependent(this.selectMedewerkerDialog);
		}
		this.selectMedewerkerDialog.open("");
	}

	public onMedewerkerDialogSearch(event: SelectDialog$SearchEvent): void {
		const query = event.getParameter("value");
		const binding = event.getParameter("itemsBinding") as ListBinding;
		if (!query) {
			binding.filter([]);
			return;
		}
		binding.filter([
			new Filter({
				and: false,
				filters: [
					new Filter({ path: "voornaam", operator: FilterOperator.Contains, value1: query, caseSensitive: false }),
					new Filter({ path: "achternaam", operator: FilterOperator.Contains, value1: query, caseSensitive: false }),
					new Filter({ path: "pernr", operator: FilterOperator.Contains, value1: query, caseSensitive: false }),
					new Filter({ path: "personID", operator: FilterOperator.Contains, value1: query, caseSensitive: false })
				]
			})
		]);
	}

	public onMedewerkerDialogConfirm(event: SelectDialog$ConfirmEvent): void {
		const listItem = event.getParameter("selectedItem");
		if (!listItem) {
			return;
		}
		const context = listItem.getBindingContext("medewerkers")!;
		const medewerker = context.getObject() as Medewerker;
		const model = this.getModel("detail") as JSONModel;
		model.setProperty("/medewerker", medewerker);
		model.setProperty("/pageTitle", `${medewerker.voornaam} ${medewerker.achternaam}`);
	}

	public onMedewerkerDialogCancel(): void {
		// niets te doen
	}

	public async onSelectMaatschappij(): Promise<void> {
		if (!this.selectMaatschappijDialog) {
			this.selectMaatschappijDialog = (await Fragment.load({
				id: this.getView()!.getId(),
				name: "inzetapp.view.fragment.SelectMaatschappijDialog",
				controller: this
			})) as SelectDialog;
			this.getView()!.addDependent(this.selectMaatschappijDialog);
		}
		this.selectMaatschappijDialog.open("");
	}

	public onMaatschappijDialogSearch(event: SelectDialog$SearchEvent): void {
		const query = event.getParameter("value");
		const binding = event.getParameter("itemsBinding") as ListBinding;
		if (!query) {
			binding.filter([]);
			return;
		}
		binding.filter([new Filter({ path: "naam", operator: FilterOperator.Contains, value1: query, caseSensitive: false })]);
	}

	public onMaatschappijDialogConfirm(event: SelectDialog$ConfirmEvent): void {
		const listItem = event.getParameter("selectedItem");
		if (!listItem) {
			return;
		}
		const context = listItem.getBindingContext("maatschappijen")!;
		const maatschappijID = context.getProperty("maatschappijID") as string;
		const naam = context.getProperty("naam") as string;
		const model = this.getModel("detail") as JSONModel;
		model.setProperty("/maatschappijID", maatschappijID);
		model.setProperty("/maatschappijNaam", naam);
	}

	public onMaatschappijDialogCancel(): void {
		// niets te doen
	}

	public async onShowMaatschappijDetails(): Promise<void> {
		const model = this.getModel("detail") as JSONModel;
		const maatschappijID = model.getProperty("/maatschappijID") as string;
		if (!maatschappijID) {
			return;
		}
		const maatschappij = this.getMockDataService().findMaatschappij(maatschappijID);
		if (!maatschappij) {
			return;
		}

		if (!this.maatschappijInfoDialog) {
			this.maatschappijInfoDialog = (await Fragment.load({
				id: this.getView()!.getId(),
				name: "inzetapp.view.fragment.MaatschappijInfoDialog",
				controller: this
			})) as Dialog;
			this.getView()!.addDependent(this.maatschappijInfoDialog);
		}
		this.maatschappijInfoDialog.setModel(new JSONModel(maatschappij), "maatschappijInfo");
		this.maatschappijInfoDialog.open();
	}

	public onCloseMaatschappijInfoDialog(): void {
		this.maatschappijInfoDialog?.close();
	}
}
