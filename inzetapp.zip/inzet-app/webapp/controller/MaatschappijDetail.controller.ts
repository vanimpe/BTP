import BaseController from "./BaseController";
import JSONModel from "sap/ui/model/json/JSONModel";
import MessageToast from "sap/m/MessageToast";
import { Route$PatternMatchedEvent } from "sap/ui/core/routing/Route";
import { Maatschappij } from "../model/types";

interface DetailData {
	isNew: boolean;
	editable: boolean;
	busy: boolean;
	pageTitle: string;
	maatschappij: Omit<Maatschappij, "maatschappijID">;
}

function emptyMaatschappij(): DetailData["maatschappij"] {
	return {
		naam: "",
		adres: "",
		emailAlgemeen: "",
		telefoon: "",
		emailFacturatie: "",
		contactpersoon: "",
		emailContactpersoon: ""
	};
}

/**
 * @namespace inzetapp.controller
 */
export default class MaatschappijDetailController extends BaseController {
	private originalSnapshot: DetailData | null = null;
	private currentMaatschappijID = "";

	public onInit(): void {
		this.setModel(new JSONModel(this.buildEmptyState()), "detail");

		this.getRouter().getRoute("maatschappijDetail")!.attachPatternMatched(this.onMaatschappijMatched, this);
		this.getRouter().getRoute("maatschappijCreate")!.attachPatternMatched(this.onMaatschappijCreateMatched, this);
	}

	private buildEmptyState(): DetailData {
		return {
			isNew: false,
			editable: false,
			busy: false,
			pageTitle: "",
			maatschappij: emptyMaatschappij()
		};
	}

	private onMaatschappijMatched(event: Route$PatternMatchedEvent): void {
		const args = event.getParameter("arguments") as { maatschappijID: string };
		const service = this.getMockDataService();
		const maatschappij = service.findMaatschappij(args.maatschappijID);
		if (!maatschappij) {
			this.getRouter().getTargets()?.display("notFound");
			return;
		}
		const { maatschappijID, ...rest } = maatschappij;
		const data: DetailData = {
			isNew: false,
			editable: false,
			busy: false,
			pageTitle: maatschappij.naam,
			maatschappij: rest
		};
		(this.getModel("detail") as JSONModel).setData(data);
		this.originalSnapshot = null;
		this.currentMaatschappijID = maatschappijID;
	}

	private onMaatschappijCreateMatched(): void {
		const data = this.buildEmptyState();
		data.isNew = true;
		data.editable = true;
		data.pageTitle = this.getText("nieuweMaatschappijTitle");
		(this.getModel("detail") as JSONModel).setData(data);
		this.originalSnapshot = null;
		this.currentMaatschappijID = "";
	}

	public onEdit(): void {
		const model = this.getModel("detail") as JSONModel;
		this.originalSnapshot = JSON.parse(JSON.stringify(model.getData())) as DetailData;
		model.setProperty("/editable", true);
	}

	public onCancel(): void {
		const model = this.getModel("detail") as JSONModel;
		const data = model.getData() as DetailData;
		if (data.isNew) {
			this.navToMaster();
			return;
		}
		if (this.originalSnapshot) {
			model.setData(this.originalSnapshot);
		}
		model.setProperty("/editable", false);
	}

	public onSave(): void {
		const model = this.getModel("detail") as JSONModel;
		const data = model.getData() as DetailData;

		if (!data.maatschappij.naam || !data.maatschappij.adres) {
			MessageToast.show(this.getText("foutVerplichteVeldenMaatschappij"));
			return;
		}

		model.setProperty("/busy", true);
		const service = this.getMockDataService();

		if (data.isNew) {
			const created = service.addMaatschappij(data.maatschappij);
			model.setProperty("/busy", false);
			MessageToast.show(this.getText("maatschappijOpgeslagen"));
			this.getRouter().navTo("maatschappijDetail", { maatschappijID: created.maatschappijID }, true);
		} else {
			service.updateMaatschappij(this.currentMaatschappijID, data.maatschappij);
			model.setProperty("/editable", false);
			model.setProperty("/pageTitle", data.maatschappij.naam);
			model.setProperty("/busy", false);
			MessageToast.show(this.getText("maatschappijOpgeslagen"));
		}
	}

	public onClose(): void {
		this.navToMaster();
	}
}
