import Controller from "sap/ui/core/mvc/Controller";
import UIComponent from "sap/ui/core/UIComponent";
import Router from "sap/ui/core/routing/Router";
import Model from "sap/ui/model/Model";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import Component from "../Component";
import MockDataService from "../model/MockDataService";

/**
 * @namespace inzetapp.controller
 */
export default abstract class BaseController extends Controller {
	public getRouter(): Router {
		return UIComponent.getRouterFor(this);
	}

	public getModel(name?: string): Model {
		return this.getView()!.getModel(name) as Model;
	}

	public setModel(model: Model, name?: string): void {
		this.getView()!.setModel(model, name);
	}

	public getText(key: string, args?: unknown[]): string {
		const resourceModel = this.getOwnerComponent()!.getModel("i18n") as ResourceModel;
		return (resourceModel.getResourceBundle() as { getText(k: string, a?: unknown[]): string }).getText(key, args);
	}

	public getMockDataService(): MockDataService {
		return (this.getOwnerComponent() as Component).getMockDataService();
	}

	public navToMaster(): void {
		this.getRouter().navTo("master");
	}
}
