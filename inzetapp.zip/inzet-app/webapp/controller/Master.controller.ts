import BaseController from "./BaseController";
import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import List from "sap/m/List";
import ListBinding from "sap/ui/model/ListBinding";
import { SearchField$LiveChangeEvent } from "sap/m/SearchField";
import { ListBase$ItemPressEvent } from "sap/m/ListBase";
import formatter from "../model/formatter";

/**
 * @namespace inzetapp.controller
 */
export default class MasterController extends BaseController {
	public formatter = formatter;

	public onInit(): void {
		// models are provided by the Component, no local setup needed
	}

	public onInzetSearch(event: SearchField$LiveChangeEvent): void {
		const query = event.getParameter("newValue");
		const list = this.byId("inzetList") as List;
		const binding = list.getBinding("items") as ListBinding;
		if (!query) {
			binding.filter([]);
			return;
		}
		const filter = new Filter({
			filters: [
				new Filter({ path: "medewerkerNaam", operator: FilterOperator.Contains, value1: query, caseSensitive: false }),
				new Filter({ path: "pernr", operator: FilterOperator.Contains, value1: query, caseSensitive: false }),
				new Filter({ path: "personID", operator: FilterOperator.Contains, value1: query, caseSensitive: false })
			],
			and: false
		});
		binding.filter([filter]);
	}

	public onMaatschappijSearch(event: SearchField$LiveChangeEvent): void {
		const query = event.getParameter("newValue");
		const list = this.byId("maatschappijList") as List;
		const binding = list.getBinding("items") as ListBinding;
		if (!query) {
			binding.filter([]);
			return;
		}
		binding.filter([new Filter({ path: "naam", operator: FilterOperator.Contains, value1: query, caseSensitive: false })]);
	}

	public onInzetPress(event: ListBase$ItemPressEvent): void {
		const listItem = event.getParameter("listItem")!;
		const context = listItem.getBindingContext("inzetList")!;
		const inzetID = context.getProperty("inzetID") as string;
		this.getRouter().navTo("inzetDetail", { inzetID });
	}

	public onMaatschappijPress(event: ListBase$ItemPressEvent): void {
		const listItem = event.getParameter("listItem")!;
		const context = listItem.getBindingContext("maatschappijen")!;
		const maatschappijID = context.getProperty("maatschappijID") as string;
		this.getRouter().navTo("maatschappijDetail", { maatschappijID });
	}

	public onAddInzet(): void {
		this.getRouter().navTo("inzetCreate");
	}

	public onAddMaatschappij(): void {
		this.getRouter().navTo("maatschappijCreate");
	}
}
