import ComponentContainer from "sap/ui/core/ComponentContainer";

new ComponentContainer({
	name: "inzetapp",
	settings: {
		id: "inzetapp"
	},
	async: true,
	height: "100%",
	width: "100%"
}).placeAt("content");
