import UIComponent from "sap/ui/core/UIComponent";
import MockDataService from "./model/MockDataService";
import { createDeviceModel } from "./model/models";

/**
 * @namespace inzetapp
 */
export default class Component extends UIComponent {
	public static metadata = {
		manifest: "json",
		interfaces: ["sap.ui.core.IAsyncContentCreation"]
	};

	private mockDataService: MockDataService;

	public init(): void {
		super.init();

		this.mockDataService = new MockDataService();
		this.setModel(this.mockDataService.getModel("medewerkers"), "medewerkers");
		this.setModel(this.mockDataService.getModel("maatschappijen"), "maatschappijen");
		this.setModel(this.mockDataService.getModel("inzetten"), "inzetten");
		this.setModel(this.mockDataService.getModel("inzetList"), "inzetList");

		this.setModel(createDeviceModel(), "device");

		this.getRouter().initialize();
	}

	public getMockDataService(): MockDataService {
		return this.mockDataService;
	}
}
