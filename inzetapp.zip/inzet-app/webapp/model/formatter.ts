import { InzetStatus } from "./types";

export default {
	statusState(status: InzetStatus): string {
		switch (status) {
			case "Gepland":
				return "Information";
			case "Actief":
				return "Success";
			case "Beëindigd":
				return "None";
			case "Geannuleerd":
				return "Error";
			default:
				return "None";
		}
	},

	statusIcon(status: InzetStatus): string {
		switch (status) {
			case "Gepland":
				return "sap-icon://date-time";
			case "Actief":
				return "sap-icon://status-positive";
			case "Beëindigd":
				return "sap-icon://status-inactive";
			case "Geannuleerd":
				return "sap-icon://status-negative";
			default:
				return "sap-icon://status-inactive";
		}
	},

	kostDisplay(kost: number): string {
		if (kost === undefined || kost === null) {
			return "";
		}
		return new Intl.NumberFormat("nl-BE", {
			style: "currency",
			currency: "EUR",
			maximumFractionDigits: 0
		}).format(kost);
	},

	fullName(voornaam: string, achternaam: string): string {
		return [voornaam, achternaam].filter(Boolean).join(" ");
	},

	dateDisplay(isoDate: string): string {
		if (!isoDate) {
			return "";
		}
		const date = new Date(isoDate);
		if (isNaN(date.getTime())) {
			return isoDate;
		}
		return new Intl.DateTimeFormat("nl-BE", {
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		}).format(date);
	}
};
