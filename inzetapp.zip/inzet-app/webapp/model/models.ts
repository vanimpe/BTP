import Device from "sap/ui/Device";
import JSONModel from "sap/ui/model/json/JSONModel";

export function createDeviceModel(): JSONModel {
	const deviceModel = new JSONModel(Device);
	deviceModel.setDefaultBindingMode("OneWay");
	return deviceModel;
}
