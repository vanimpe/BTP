export interface Medewerker {
	personID: string;
	pernr: string;
	voornaam: string;
	achternaam: string;
	kostcenter: string;
	kostenplaats: string;
	functie: string;
	band: string;
}

export interface Maatschappij {
	maatschappijID: string;
	naam: string;
	adres: string;
	emailAlgemeen: string;
	telefoon: string;
	emailFacturatie: string;
	contactpersoon: string;
	emailContactpersoon: string;
}

export type InzetStatus = "Gepland" | "Actief" | "Beëindigd" | "Geannuleerd";

export type Werkrooster = "Voltijds" | "Deeltijds 4/5" | "Deeltijds 1/2" | "Deeltijds 3/5";

export interface Inzet {
	inzetID: string;
	personID: string;
	maatschappijID: string;
	startdatum: string;
	einddatum: string;
	functieOfVacature: string;
	werkrooster: Werkrooster;
	contractdatum: string;
	kostEuro: number;
	status: InzetStatus;
}

export interface InzetListItem extends Inzet {
	medewerkerNaam: string;
	pernr: string;
	personID: string;
	maatschappijNaam: string;
}
