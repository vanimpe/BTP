import JSONModel from "sap/ui/model/json/JSONModel";
import { Inzet, InzetListItem, Maatschappij, Medewerker } from "./types";

type ModelName = "medewerkers" | "maatschappijen" | "inzetten" | "inzetList";

export default class MockDataService {
	private medewerkersModel: JSONModel;
	private maatschappijenModel: JSONModel;
	private inzettenModel: JSONModel;
	private inzetListModel: JSONModel;

	constructor() {
		this.medewerkersModel = new JSONModel();
		this.medewerkersModel.loadData(sap.ui.require.toUrl("inzetapp/model/data/medewerkers.json"));

		this.maatschappijenModel = new JSONModel();
		this.maatschappijenModel.loadData(sap.ui.require.toUrl("inzetapp/model/data/maatschappijen.json"));

		this.inzettenModel = new JSONModel();
		this.inzettenModel.loadData(sap.ui.require.toUrl("inzetapp/model/data/inzetten.json"));

		this.inzetListModel = new JSONModel({ items: [] });

		Promise.all([
			this.medewerkersModel.dataLoaded(),
			this.maatschappijenModel.dataLoaded(),
			this.inzettenModel.dataLoaded()
		]).then(() => this.refreshInzetList());
	}

	public getModel(name: ModelName): JSONModel {
		switch (name) {
			case "medewerkers":
				return this.medewerkersModel;
			case "maatschappijen":
				return this.maatschappijenModel;
			case "inzetten":
				return this.inzettenModel;
			case "inzetList":
				return this.inzetListModel;
			default:
				throw new Error(`Onbekend model: ${name as string}`);
		}
	}

	public getMedewerkers(): Medewerker[] {
		return (this.medewerkersModel.getProperty("/items") as Medewerker[]) || [];
	}

	public findMedewerker(personID: string): Medewerker | undefined {
		return this.getMedewerkers().find((m) => m.personID === personID);
	}

	public getMaatschappijen(): Maatschappij[] {
		return (this.maatschappijenModel.getProperty("/items") as Maatschappij[]) || [];
	}

	public findMaatschappij(maatschappijID: string): Maatschappij | undefined {
		return this.getMaatschappijen().find((m) => m.maatschappijID === maatschappijID);
	}

	public getInzetten(): Inzet[] {
		return (this.inzettenModel.getProperty("/items") as Inzet[]) || [];
	}

	public findInzet(inzetID: string): Inzet | undefined {
		return this.getInzetten().find((i) => i.inzetID === inzetID);
	}

	public addInzet(data: Omit<Inzet, "inzetID">): Inzet {
		const items = this.getInzetten();
		const nextNumber = items.length + 1;
		const inzetID = `I${String(nextNumber).padStart(4, "0")}`;
		const newInzet: Inzet = { ...data, inzetID };
		items.push(newInzet);
		this.inzettenModel.setProperty("/items", items);
		this.refreshInzetList();
		return newInzet;
	}

	public updateInzet(inzetID: string, changes: Partial<Inzet>): void {
		const items = this.getInzetten();
		const index = items.findIndex((i) => i.inzetID === inzetID);
		if (index === -1) {
			return;
		}
		items[index] = { ...items[index], ...changes };
		this.inzettenModel.setProperty("/items", items);
		this.refreshInzetList();
	}

	public addMaatschappij(data: Omit<Maatschappij, "maatschappijID">): Maatschappij {
		const items = this.getMaatschappijen();
		const nextNumber = items.length + 1;
		const maatschappijID = `M${String(nextNumber).padStart(3, "0")}`;
		const newMaatschappij: Maatschappij = { ...data, maatschappijID };
		items.push(newMaatschappij);
		this.maatschappijenModel.setProperty("/items", items);
		this.refreshInzetList();
		return newMaatschappij;
	}

	public updateMaatschappij(maatschappijID: string, changes: Partial<Maatschappij>): void {
		const items = this.getMaatschappijen();
		const index = items.findIndex((m) => m.maatschappijID === maatschappijID);
		if (index === -1) {
			return;
		}
		items[index] = { ...items[index], ...changes };
		this.maatschappijenModel.setProperty("/items", items);
		this.refreshInzetList();
	}

	private refreshInzetList(): void {
		const medewerkers = this.getMedewerkers();
		const maatschappijen = this.getMaatschappijen();

		const list: InzetListItem[] = this.getInzetten().map((inzet) => {
			const medewerker = medewerkers.find((m) => m.personID === inzet.personID);
			const maatschappij = maatschappijen.find((m) => m.maatschappijID === inzet.maatschappijID);
			return {
				...inzet,
				medewerkerNaam: medewerker ? `${medewerker.voornaam} ${medewerker.achternaam}` : "",
				pernr: medewerker ? medewerker.pernr : "",
				personID: inzet.personID,
				maatschappijNaam: maatschappij ? maatschappij.naam : ""
			};
		});

		this.inzetListModel.setProperty("/items", list);
	}
}
